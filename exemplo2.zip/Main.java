public class Main {
    public static void main(String[] args) {
        // Primeiro objeto
        Pessoa pessoa1 = new Pessoa("Ana Silva", "F", "R. Flores, 123");

        // Segundo objeto
        Pessoa pessoa2;
        pessoa2 = new Pessoa("Bruno Costa", "M", "Av. Paulista, 900");

        // Chamando o método mostrarDados para ambos
        pessoa1.mostrarDados();
        pessoa2.mostrarDados();
    }
}