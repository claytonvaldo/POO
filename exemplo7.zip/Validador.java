public interface Validador {
  public void validarCH();
}