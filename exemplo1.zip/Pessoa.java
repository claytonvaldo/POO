public class Pessoa {
    // Atributos
    public String nome;
    public String sexo;
    public String endereco;

    // Construtor
    public Pessoa(String nome, String sexo, String endereco) {
        this.nome = nome;
        this.sexo = sexo;
        this.endereco = endereco;
    }

    // Método para exibir as informações
    public void mostrarDados() {
        System.out.println("--- Dados da Pessoa ---");
        System.out.println("Nome: " + this.nome);
        System.out.println("Sexo: " + this.sexo);
        System.out.println("Endereço: " + this.endereco);
        System.out.println("-----------------------");
    }
}