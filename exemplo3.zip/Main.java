public class Main {
    public static void main(String[] args) {
      Professor professor101 = new Professor(101, 3500, "Edgar Dijkstra", "M", "R. Acadêmica, 50");
      Aluno aluno202 = new Aluno(202, 950, "Mariana Souza", "F", "R. Lírio, 77");

      professor101.mostrarDados();
      System.out.println();
      aluno202.mostrarDados();
    }
}